#include "iostream"
#include "stdio.h"
#include "pico/stdlib.h"
#include "pico/time.h"
#include "hardware/irq.h"
#include "hardware/pwm.h"


class GPLED{
    private:
        int pin;
        inline static int pinSt;

        void static fading_mode(){
            static int fade = 0;
            static bool going_up = true;
            // int static pinSt = static_cast<int>(pin);
            pwm_clear_irq(pwm_gpio_to_slice_num(pinSt));

            if (going_up){
                ++fade; if (fade > 255){
                    fade = 255; going_up = false;
                }
            } else {
                --fade; if (fade < 0){
                    fade = 0; going_up = true;
                }
            }
            pwm_set_gpio_level(pinSt, fade * fade);
        }
        
    public:
        GPLED(int pin){
            this->pin = pin;
            pinSt = pin;
        }
        ~GPLED();

        int Get_Pin(){return pin;}
        
       
        void Set_fade_mode(){
            // void on_pwm_wrap = fading; 
            gpio_set_function(pin, GPIO_FUNC_PWM);

            uint slice_num = pwm_gpio_to_slice_num(pin);

            pwm_clear_irq(slice_num);
            pwm_set_irq_enabled(slice_num, true);
            
            irq_set_exclusive_handler(PWM_IRQ_WRAP, fading_mode);
            irq_set_enabled(PWM_IRQ_WRAP, true);

            pwm_config config = pwm_get_default_config();
            pwm_config_set_clkdiv(&config, 4.f);
            pwm_init(slice_num,&config,true);
        }
        
};

int main(){
    stdio_init_all();

    GPLED led0(PICO_DEFAULT_LED_PIN);
    led0.Set_fade_mode();
    
    while (1){
        // std::cout << led0.Get_Pin() << std::endl; 
    }
    return 0;
}